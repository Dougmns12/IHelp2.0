<html>
<head> Página Inicial </head>
<body>
<table>
	<tr>
		<td colspan="2"> <h2> Menu </h2> </td>
	</tr>
	<tr>
		<td> Cadastrar Pessoa</td>
		<td> <a href="cadastrar.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td> Atualizar Pessoa</td>
		<td> <a href="atualizar.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td> Excluir Pessoa</td>
		<td> <a href="excluir.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td> Consultar Pessoa</td>
		<td> <a href="consultar.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td>Cadastrar Carro:</td>
		<td> <a href="cadastrarcarro.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td>Excluir Carro:</td>
		<td> <a href="excluirCarro.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td>Atualizar Carro:</td>
		<td> <a href="atualizarCarro.php"> >>>>> </a> </td>
	</tr>
	<tr>
		<td>Carro Pessoa:</td>
		<td> <a href="cadastrarpessoascarro.php"> >>>>> </a> </td>
	</tr>
</table>
</body>
</html>